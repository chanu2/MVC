package SCH_JOIN.join;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoinApplicationTests {

	@Test
	void contextLoads() {
	}

}
