package farmconnect.farmconnectbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmConnectBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
