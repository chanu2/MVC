# farm-connect-backend

<img src="/farm-connect-ERD.PNG" width="100%" />
